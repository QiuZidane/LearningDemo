localStorage.setItem('playername','zidane');
localStorage.setItem('loginflag','1');
alert('已登陆');